package com.capgemini.product.service;

import com.capgemini.product.beans.Order;
import com.capgemini.product.dao.ProductDao;
import com.capgemini.product.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService {
	
	private static ProductDao dao = new ProductDaoImpl();
	
	public int calculateOrder(Order o) {
		double s = (((o.getPrice()*75)*1.25)/100);
		o.setCurrency1(s);
		double t = o.getCurrency1()+(o.getPrice()*75);
		o.setPrice(t);
		double b = o.getPrice()*o.getQuantity();
		o.setPrice(b);
		return dao.saveOrder(o);
	}
	

}
