package com.capgemini.product.beans;

public class Order {
	
	private double price;
	private double currency1;
	private int quantity;
	private int id;
	private String name;
	
	
	public int getQuantity() {
		return quantity;
	}
	public int setQuantity(int quantity) {
		return this.quantity = quantity;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getCurrency1() {
		return currency1;
	}
	public void setCurrency1(double currency1) {
		this.currency1 = currency1;
	}
	public Order(double price, double currency1) {
		super();
		this.price = price;
		this.currency1 = currency1;
	}
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Order [price=" + price + ", currency1=" + currency1 + ", quantity=" + quantity + ", id=" + id
				+ ", name=" + name + "]";
	}
	

}
