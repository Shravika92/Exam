package com.capgemini.product.dao;

import java.util.ArrayList;
import java.util.List;

//import com.capgemini.product.validation.Validate;
import com.capgemini.product.beans.Order;

public class ProductDaoImpl implements ProductDao {
	
	private List<Order> l1 = new ArrayList<Order>();
	
	public void save(Order o) {
		l1.add(o);	
	}
	
	@Override
	public int saveOrder(Order o) {
		// TODO Auto-generated method stub
		l1.add(o);
		System.out.println(l1);
		return 0;
	}
	

}
